public class InvalidFragmentSizeException extends Exception {
	
	public InvalidFragmentSizeException(String message){
	
		super(message);
		
	}
}
