public class NoFileSpecifiedException extends Exception{
	
	public NoFileSpecifiedException(String message){
	
		super(message);
		
	}
}