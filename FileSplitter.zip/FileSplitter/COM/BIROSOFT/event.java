/* Developed by Swastik Ku. Sahoo  */
import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;
import java.lang.*;
import java.sql.*;

public class event extends JFrame implements ActionListener{
    Connection con;
    Statement stmt;
    ResultSet rs;
    ResultSetMetaData rmd;

    JButton btn,Save,Display,Delete,Edit,Exit,Next,search,report,Previous;
    JTextArea txtarea;
    JTextField tx1,tx2,tx3,tx4;
    String btnval,del;
    String setAge,namWrite;
    Vector<String> strName,strFather,strAge,strAddr;
    Integer columncount,no_rows;
    int i=1;
    FileOutputStream output1;
    BufferedWriter output2;

    public event(){
        Container container=this.getContentPane();
        container.setLayout(new BorderLayout());

        JPanel northpanel=new JPanel();
        container.add(northpanel,BorderLayout.NORTH);
        northpanel.setBorder(new BevelBorder (BevelBorder.LOWERED));

        JPanel eastpanel=new JPanel(new GridLayout(2,1));
        container.add(eastpanel,BorderLayout.EAST);
        eastpanel.setBorder(new TitledBorder(new LineBorder(Color.red),"Record Display"));

            JLabel lbl= new JLabel(new ImageIcon("scroller.jpg"));
            eastpanel.add(lbl);

            txtarea=new JTextArea();
            txtarea.setRows(5);
            eastpanel.add(txtarea);

        JPanel westpanel=new JPanel(new GridLayout(4,2));
        container.add(westpanel,BorderLayout.WEST);
        westpanel.setBorder(new TitledBorder(new LineBorder(Color.red),"DataEntry"));

            JLabel lbl1=new JLabel("Name");
            JLabel lbl2=new JLabel("Father");
            JLabel lbl3=new JLabel("Age");
            JLabel lbl4=new JLabel("Address");

            tx1=new JTextField();
            tx2=new JTextField();
            tx3=new JTextField();
            tx4=new JTextField();

            westpanel.add(lbl1);
            westpanel.add(tx1);
            westpanel.add(lbl2);
            westpanel.add(tx2);
            westpanel.add(lbl3);
            westpanel.add(tx3);
            westpanel.add(lbl4);
            westpanel.add(tx4);

        JPanel southpanel=new JPanel(new GridLayout(1,9,2,2));
        container.add(southpanel,BorderLayout.SOUTH);
        southpanel.setBorder(new CompoundBorder(new EtchedBorder(Color.green,Color.green),new LineBorder(Color.red)));
            Save = new  JButton("Save");
            Save.setBorder(new CompoundBorder());
            Display = new JButton("Display");
            Display.setBorder(new CompoundBorder());
            Delete = new JButton("Delete");
            Delete.setBorder(new CompoundBorder());
            Edit = new JButton("Edit");
            Edit.setBorder(new CompoundBorder());
            Next = new JButton("Next");
            Next.setBorder(new CompoundBorder());
            Exit = new JButton("Exit");
            Exit.setBorder(new CompoundBorder());
            report = new JButton("Report");
            report.setBorder(new CompoundBorder());
            search = new JButton("Search");
            search.setBorder(new CompoundBorder());
            search.setToolTipText("Please Insert a Name in th name field");
            Previous = new JButton("Previous");
            Previous.setBorder(new CompoundBorder());

            Save.setBackground(Color.cyan);
            Display.setBackground(Color.cyan);
            Edit.setBackground(Color.cyan);
            Exit.setBackground(Color.cyan);
            Delete.setBackground(Color.cyan);
            Next.setBackground(Color.cyan);
            search.setBackground(Color.cyan);
            report.setBackground(Color.cyan);
            Previous.setBackground(Color.cyan);

            southpanel.add(Save);
            southpanel.add(Display);
            southpanel.add(Delete);
            southpanel.add(Edit);
            southpanel.add(Next);
            southpanel.add(search);
            southpanel.add(report);
            southpanel.add(Previous);
            southpanel.add(Exit);

            Save.addActionListener(this);
            Display.addActionListener(this);
            Edit.addActionListener(this);
            Exit.addActionListener(this);
            Delete.addActionListener(this);
            Next.addActionListener(this);
            search.addActionListener(this);
            report.addActionListener(this);
            Previous.addActionListener(this);

        JPanel centerpanel=new JPanel(new GridLayout(8,4));
        container.add(centerpanel,BorderLayout.CENTER);
        centerpanel.setBorder(new SoftBevelBorder((SoftBevelBorder.RAISED)));

        for(int i=1;i<=31;i++){
            JButton btn=new JButton(String.valueOf(i));
            btn.addActionListener(this);
            centerpanel.add(btn);
        }

        this.openDatabases();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,100,700,250);
        this.setVisible(true);
    }

    public void openDatabases(){
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/bhabani");
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery("select * from test"); 
            if(rs.next()) this.displayRow();
            rmd = rs.getMetaData();
        } catch(ClassNotFoundException e) {
        } catch(SQLException e) {
        } catch(Exception e) {
        }
    }

    public void dataclose() {
        try {
            con.close(); stmt.close(); rs.close();
        } catch(SQLException e){
        } catch(Exception e){
        }
    }

    public void actionPerformed(ActionEvent ae){
        String command = ae.getActionCommand();
        int dateButton;
        boolean exception = true;

        try {
            dateButton = Integer.parseInt(command);
        } catch(NumberFormatException e) {
            exception = false;
        } catch(Exception e) {
        }

        if(exception) {
            txtarea.setText(command);
        } else if(command.equalsIgnoreCase("exit")) {
            this.dataclose();
            i=1;
            System.exit(0);
        } else if(command.equalsIgnoreCase("display")) {
            this.openDatabases();
            try {
                rs=stmt.executeQuery("select * from test");

                strName=new Vector<String>();
                strFather=new Vector<String>();
                strAge=new Vector<String>();
                strAddr=new Vector<String>();
                int i=0;
                while(rs.next()) {
                    strName.add(rs.getString("name"));
                    strFather.add(rs.getString("father"));
                    strAge.add((rs.getString("age")).toString());
                    strAddr.add(rs.getString("addr"));

                    txtarea.setText("Name       : "+strName.toString()+"\n"+
                                    "Father     : "+strFather.toString()+"\n"+
                                    "Age        : "+strAge.toString()+"\n"+
                                    "Address    : "+strAddr.toString());

                }
                tx1.setText("");
                tx2.setText("");
                tx3.setText("");
                tx4.setText("");
            } catch (SQLException e){
            } catch (Exception e){
            } finally {
                this.dataclose();
            }
        } else if(command.equalsIgnoreCase("delete")) {
            this.openDatabases();
            try {
                del=tx1.getText();
                rs=stmt.executeQuery("delete from test where name='"+del+"'");
                rs=stmt.executeQuery("commit");
                //require message if record not found
                tx1.setText("");
                tx2.setText("");
                tx3.setText("");
                tx4.setText("");
            } catch(SQLException e){
                txtarea.setText("Record of :"+del+"  not Found");
            } catch(Exception e) {
            } finally {
                this.dataclose();
            }
            txtarea.setText("Record of :"+del+"  is deleted");
        } else if(command.equalsIgnoreCase("search")) {
            this.openDatabases();
            try {
                String getVal=tx1.getText();
                int record=getVal.length();
                String getVal2=tx2.getText();
                int record2=getVal2.length();
                String getVal3=tx3.getText();
                int record3=getVal3.length();
                String getVal4=tx4.getText();
                int record4=getVal4.length();
                if(record > 0) {
                    rs = stmt.executeQuery("select * from test where name='"+getVal+"'");
                } else if(record2 > 0) {
                    rs = stmt.executeQuery("select * from test where father='"+getVal2+"'");
                } else if(record3 > 0) {
                    rs = stmt.executeQuery("select * from test where age='"+getVal3+"'");
                } else if(record4 > 0) {
                    rs = stmt.executeQuery("select * from test where addr='"+getVal4+"'");
                } else {
                    txtarea.setText("Enter a Name or Father's Name or Age Or Address ");
                }

                while(rs.next()) {
                    String nam=rs.getString("name");
                    String fath=rs.getString("father");
                    Integer ag=rs.getInt("age");
                    String addr=rs.getString("addr");
                    tx1.setText("");
                    tx2.setText("");
                    tx3.setText("");
                    tx4.setText("");
                    txtarea.setText("name :"+nam+"\n"+"Father :"+fath+"\n"+"Age :"+ag.toString()+"\n"+"Address :"+addr+"\n");
                }
            } catch(SQLException e) {
            } catch(Exception e) {
            } finally {
                this.dataclose();
            }
        } else if(command.equalsIgnoreCase("save")) {
            this.openDatabases();
            try {
                String tx1val=tx1.getText();
                String tx2val=tx2.getText();
                Integer tx3val=Integer.parseInt(tx3.getText());
                String tx4val=tx4.getText();
                String query="insert into test values('"+tx1val+"','"+tx2val+"',"+tx3val+",'"+tx4val+"')";
                stmt.executeUpdate(query);
                rs=stmt.executeQuery("commit");
                txtarea.setText("Successfully Inserted");
                tx1.setText("");
                tx2.setText("");
                tx3.setText("");
                tx4.setText("");
            } catch(SQLException e) {
                System.out.println(e);
            } catch(Exception e) {
                txtarea.setText("Not a Valid Data");
            } finally {
                this.dataclose();
            }
        } else if(command.equalsIgnoreCase("report")){
            //requires report generation in text area /Io/Crystal
            try {
                output1 = new FileOutputStream("Report1.txt");
                output2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Report.txt", true)));
                this.openDatabases();
                rs=stmt.executeQuery("select * from test");
                while (rs.next()){
                    Integer getAge=rs.getInt("age");
                    setAge=getAge.toString();
                    namWrite =  "Name       : "+rs.getString("name")+
                                "Father     : "+rs.getString("father")+
                                "Age        : "+setAge+
                                "Address    : "+rs.getString("addr");
                }
            } catch (IOException e){
                System.out.println("Error in writing");
            } catch (SQLException e){
                System.out.println("data not found");
            } catch (Exception e){
                System.out.println("****");
            } finally {
                this.dataclose();
            }

            try{
                output1.write(namWrite.getBytes());
                output2.write(namWrite,0,namWrite.length());
            }catch (IOException e){
                System.out.println("Error in writing");
            }
        }else if(command.equalsIgnoreCase("edit")){
            this.openDatabases();
            try {
                String getVal=tx1.getText();
                String getVal2=tx2.getText();
                String getVal3=tx3.getText();
                String getVal4=tx4.getText();
                rs=stmt.executeQuery("select * from test");
                rs.last();
                Integer rowc=rs.getRow();
            }catch (SQLException e){
            }catch (Exception e){
            }finally{
                this.dataclose();
            }
        } else if(command.equalsIgnoreCase("previous")){
            try {
                int currentRow = rs.getRow();
                if(currentRow>1) {
                    rs.previous();
                    this.displayRow();
                }
            } catch(SQLException e){
                System.err.println(e);
            } catch(Exception e){
                System.err.println(e);
            }
        } else if(command.equalsIgnoreCase("next")){
            try {
                int currentRow = rs.getRow();
                rs.last();
                int lastRow = rs.getRow();
                rs.absolute(currentRow);
                if(currentRow<lastRow) {
                    rs.next();
                    this.displayRow();
                }
            } catch(SQLException e) {
                System.err.println(e);
            } catch(Exception e) {
                System.err.println(e);
            }
        }
    }

    public void displayRow() {
        try {
            String strName   = rs.getString("name");
            String strFather = rs.getString("father");
            String strAge    = rs.getString("age").toString();
            String strAddr   = rs.getString("addr");

            tx1.setText(strName);
            tx2.setText(strFather);
            tx3.setText(strAge);
            tx4.setText(strAddr);

            txtarea.setText("Name       : "+strName+"\n"+
                            "Father     : "+strFather+"\n"+
                            "Age        : "+strAge+"\n"+
                            "Address    : "+strAddr);

        } catch(SQLException e) {
            System.err.println(e);
        } catch(Exception e) {
            System.err.println(e);
        }
    }

    public static void main(String[] args)  {
        new event();
    }
}
